$(document).ready(function () {
  /* ****************Slider & Value*************** */

  $("#AgeRangeSlider").slider({
    min: 18,
    max: 100,
    value: 18,
    slide: function (event, ui) {
      $("#AgeValue").val(ui.value);
    },
  });
  $("#AgeValue").val($("#AgeRangeSlider").slider("value"));

  $("#PriceValue").slider({
    min: 1,
    max: 500,
    range: true,
    values: [1, 50],
    start: function (event, ui) {
      $("#startvalue").val("$" + ui.values[0]);
    },
    stop: function (event, ui) {
      $("#endvalue").val("$" + ui.values[1]);
    },
    change: function (event, ui) {
      $("#changevalue").val("$" + ui.values[0] + " - $" + ui.values[1]);
    },
    slide: function (event, ui) {
      $("#slidevalue").val("$" + ui.values[0] + " - $" + ui.values[1]);
    },
  });
});
