$(document).ready(function () {
    $("#1").click(function () {
        // alert('hello');
        $("#01").hide(500);
        $(this).attr("disabled",true);
        $("#2").attr("disabled",false);
      });
/* ******************************************** */ 
      $("#2").click(function () {
          // alert('hello guys');
          $("#01").show(500);
          $(this).attr("disabled",true);
          $("#1").attr("disabled",false);
      });
      
/* ******************************************** */ 

      $("#3").click(function () {
        // alert('guys');
        // $("#01").width(500);
        // $("#01").height(500);
        var ZI=parseInt($("#01").css("height"));
    
        if (ZI<=500) {
          ZI+=50;
          $("#01").css("height", ZI);
          $("#01").css("width", ZI);
        } 
        else {
          alert("More Than 500px is not possible.");
        }
      });

/* ******************************************** */ 

      $("#4").click(function () {
        // alert('llo gu');
        // $("#01").width(150);
        // $("#01").height(150);
        var ZO=parseInt($("#01").css("height"));
        if (ZO>=80) {
          ZO-=20;
          $("#01").css("height", ZO);
          $("#01").css("width", ZO);
        } else {
          alert("More Than 80px is not possible.");
        }
      });
});
