$(document).ready(function () {
  /* ****************Accordion******************* */

  $("#MyAccordion").accordion();

  /* ****************Date_picker****************** */

  $("#MyDOBPicker1").datepicker({
    // showWeek: true,
    changeYear: true,
    showAnim: "slide",
    changeMonth: true,
    // yearSuffix: "(DOB)",
    // currentText: "yesterday", 
    // calculateWeek: "myWeekCalc",

  });
  // $("#MyDOBPicker1").datepicker();
  $("#MyDOBPicker2").datepicker();

  /* ********************Pop_Up******************* */

  $("#MyDiv").dialog({
    autoOpen: false,
  });
  $("#MyButton").click(function () {
    $("#MyDiv").dialog({
      autoOpen: true,
    });
  });

  /* **********************Spinner********************** */

  $("#MyValueList").spinner();

  /* **********************TabMenu********************** */

  $("#MyTabDiv").tabs();
});