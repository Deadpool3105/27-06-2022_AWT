//Reg Ex Declaration - Globaly.
var $FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
var $FullNameRegEx = /^([a-zA-Z ]{2,40})$/;
var $BankAccountNameRegEx = /^([a-zA-Z ]{2,60})$/;
var $PasswordRegEx =
  /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,12}$/;
var $EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;
var $ConNoRegEx = /^([0-9]{10})$/;
var $AgeRegEx = /^([0-9]{1,2})$/;
var $AadhaarNoRegEx = /^([0-9]{12})$/;
var $GSTNoRegEx = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
var $IndianDrivingLicenseNoRegEx = /^([A-Z]{2,3}[-/0-9]{8,13})$/;
var $IndianVehicleRegNoRegEx = /^([A-Z]{2}[0-9]{1,2}[A-Z]{1,3}[0-9]{1,4})$/;
var $PincodeRegEx = /^[1-9][0-9]{5,6}$/;
var $PANNoRegEx = /^[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z]$/;
var $IFSCCodeRegEx = /^[A-Za-z]{4}0[A-Z0-9a-z]{6}$/;
var $BankAccountNoRegEx = /^([0-9]{9,18})$/;
var $LatitudeLongitude =
  /^(-?(?:1[0-7]|[1-9])?\d(?:\.\d{1,8})?|180(?:\.0{1,8})?)$/;

$(document).ready(function () {
  /* ******************************* */

  $("#TxtFirstname").blur(function () {
    $("#Validfirstname").empty();
    if ($(this).val() == "" || $(this).val() == null) {
      $("#Validfirstname").html(" *Firstname required..!!");
    } else {
      if (!$(this).val().match($FNameLNameRegEx)) {
        $("#Validfirstname").html(" *Invalid firstname..!!");
      }
    }
  });

  $("#TxtFirstname").keypress(function (e) {
    var ASCIIValue = e.which;
    $("#Validfirstname").empty();
    var Flag =
      (ASCIIValue >= 65 && ASCIIValue <= 90) ||
      (ASCIIValue >= 97 && ASCIIValue <= 121) ||
      ASCIIValue == 13;
    if (Flag == false) {
      $("#Validfirstname").html(" *Invalid input..!!");
    }
    return Flag;
  });

  /* ******************************* */

  $("#TxtLastname").blur(function () {
    $("#Validlastname").empty();
    if ($(this).val() == "" || $(this).val() == null) {
      $("#Validlastname").html(" *Lastname required..!!");
    } else {
      if (!$(this).val().match($FNameLNameRegEx)) {
        $("#Validlastname").html(" *Invalid lastname..!!");
      }
    }
  });

  $("#TxtLastname").keypress(function (e) {
    var ASCIIValue = e.which;
    $("#Validlastname").empty();

    var Flag =
      (ASCIIValue >= 65 && ASCIIValue <= 90) ||
      (ASCIIValue >= 97 && ASCIIValue <= 121) ||
      ASCIIValue == 13;
    if (Flag == false) {
      $("#Validlastname").html(" *Invalid input..!!");
    }
    return Flag;
  });

  /* ******************************* */

  $("#TxtEmailid").blur(function () {
    $("#Validemailid").empty();
    if ($(this).val() == "" || $(this).val() == null) {
      $("#Validemilid").html(" *Email id requried..!!");
    } else {
      if (!$(this).val().match($EmailIdRegEx)) {
        $("#Validemilid").html(" *Invalid Email id..!!");
      }
    }
  });

  /* ******************************* */

  $("#TxtContactNo").blur(function () {
    $("#TxtContactNoValidate").empty();
    if ($(this).val() == "" || $(this).val() == null) {
      $("#Validcontactno").html(" *Contact no. required..!!");
    } else {
      if (!$(this).val().match($ConNoRegEx)) {
        $("#Validcontactno").html(" *Invalid contact no..!!");
      }
    }
  });
  $("#TxtContactNo").keypress(function (e) {
    $("#TxtContactNoValidate").empty();
    var ASCIIValue = e.which;
    var Flag = (ASCIIValue >= 48 && ASCIIValue <= 57) || ASCIIValue == 13;
    if (Flag == false) {
      $("#errorcontact").html(" * Inavlid Input..!!");
    }
    return Flag;
  });

  /* ******************************* */

  var TxtFirstnameFlag = false,
    TxtLastnameFlag = false,
    TxtEmailidFlag = false,
    TxtContactNoFlag = false;
  $("#CreateNewAccount").click(function () {

    $("#Validfirstname").empty();
    if ($("#TxtFirstname").val() == "" || $("#TxtFirstname").val() == null) {
      $("#Validfirstname").html(" *firstname required..");
      TxtFirstnameFlag = false;
    } else {
      if (!$("#TxtFirstname").val().match($FNameLNameRegEx)) {
        $("#Validfirstname").html(" *Invalid firstname..!!");
        TxtFirstnameFlag = false;
      } else {
        TxtFirstnameFlag = true;
      }
    }

    $("#Validlastname").empty();
    if ($("#TxtLastname").val() == "" || $("#TxtLastname").val() == null) {
      $("#Validlastname").html(" *lastname required..");
      TxtLastnameFlag = false;
    } else {
      if (!$("#TxtLastname").val().match($FNameLNameRegEx)) {
        $("#Validlastname").html(" *Invalid Lastname..!!");
        TxtLastnameFlag = false;
      } else {
        TxtLastnameFlag = true;
      }
    }

    $("#Validemilid").empty();
    if ($("#TxtEmailid").val() == "" || $("#TxtEmailid").val() == null) {
      $("#Validemilid").html(" *email id requried..");
      TxtEmailidFlag = false;
    } else {
      if (!$("#TxtEmailid").val().match($EmailIdRegEx)) {
        $("#Validemilid").html(" *Invalid Email id..!!");
        TxtEmailidFlag = false;
      } else {
        TxtEmailidFlag = true;
      }
    }

    $("#Validcontactno").empty();
    if ($("#TxtContactNo").val() == "" || $("#TxtContactNo").val() == null) {
      $("#Validcontactno").html(" *contact no. required..");
      TxtContactNoFlag = false;
    } else {
      if (!$("#TxtContactNo").val().match($ConNoRegEx)) {
        $("#Validcontactno").html(" *Invalid Contact no..!!");
        TxtContactNoFlag = false;
      } else {
        TxtContactNoFlag = true;
      }
    }

    if (
      TxtFirstnameFlag == true &&
      TxtLastnameFlag == true &&
      TxtEmailidFlag == true &&
      TxtContactNoFlag == true
    ) {
      alert("Form Submitted Successfully..!!");
    } else {
      alert("Invalid Form Inputs..!!");
    }
 });
});
