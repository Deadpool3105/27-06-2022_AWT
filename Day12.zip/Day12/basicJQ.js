$(document).ready(function(){
    $("#akd").focus(function(){
        // alert('hello');
        $(this).css("background-color","red");
    });
    
    /* ******************************************* */ 

    $("#bkd").blur(function(){
        $(this).css("color","blue"  );
        // alert("hello");
    });
    
    /* ******************************************* */ 

    $("#bambe").keypress(function(){
        alert($(this).val());
    });

    /* ******************************************* */ 

    $("#bo").keyup(function(){
        alert($(this).val());
    });
});