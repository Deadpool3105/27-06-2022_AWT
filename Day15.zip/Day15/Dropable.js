$(document).ready(function () {
  $("#01").draggable();
  $("#02").draggable();

  /* ************************************** */

  $("#03").draggable();
  $("#04").droppable({
    accept: "#03",
    drop: function (event, ui) {
      $(this).find("p").value("Ho gaya bidu...! ");
    }
  });

  /* ************************************** */

  $("#05").resizable();
});
