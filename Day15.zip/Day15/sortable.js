$(document).ready(function () {
  $("#01").sortable();
  $("#02").sortable();

  $("#01").sortable({
    connectWith: "#02, #01",
  });

  $("#02").sortable({
    connectWith: "#01,#02",
  });
});
