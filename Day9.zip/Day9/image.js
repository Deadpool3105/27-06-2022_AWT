function chaimg1(){
    document.getElementById("trns1").src="../Day4/image/11.jpg"
}

function chaimg2(){
    document.getElementById("trns1").src="../Day4/image/3.jpg"

}

function chaimg3(){
    document.getElementById("trns1").src="../Day4/image/7.jpg"

}